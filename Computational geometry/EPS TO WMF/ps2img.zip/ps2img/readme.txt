C:\>ps2img.exe
-------------------------------------------------------
PS To Image Converter Copyright (C) 2000-2015 VeryPDF.com Inc.
Description:
Convert PS (Postscript) and EPS to TIF, TIFF, JPG, GIF, PNG, BMP, WMF, EMF, PCX, TGA, etc. formats
Web: http://www.verypdf.com
Web: http://www.verydoc.com
Email: support@verypdf.com
Release Date: Jan 14 2015
Usage: ps2img [options] <-i PS File> [-o Output]
-i [input PS file]   : Input PS filename
-o [output TIF file] : Output TIFF filename
-g                   : Convert to 8-bit grayscale image file, this option
                       is only available while bitcount equal 8 (-b 8)
-m                   : Set output to multi-page TIFF file, the
                       default is output to single page TIFF files
-r [resolution]      : Set resolution in generated image files
    -r 300           : Set horizontal and vertical resolution to 300 DPI
    -r 200x300       : Set horizontal and vertical resolution to 200x300 DPI
    -r 204x98        : Set horizontal and vertical resolution to 204x98 DPI
-f [first Page]      : First page to convert
-l [last Page]       : Last page to convert
-c [compress]        : Set compression method in generated image
                       files(for tif only)
    -c none          : Create TIFF file without compression
    -c lzw           : Compress TIFF using LZW arithmetic
    -c jpeg          : Compress TIFF using JPEG arithmetic
    -c packbits      : Compress TIFF using packbits arithmetic
    -c g3            : Compress TIFF using CCITT G3 arithmetic
    -c g4            : Compress TIFF using CCITT G4 arithmetic
    -c ClassF        : Compress TIFF into Fax compatible ClassF 204x98 format
    -c ClassF196     : Compress TIFF into Fax compatible ClassF 204x196 format
-q [quality]         : Set quality in created image files(for jpeg image only)
-t                   : Enable transparent background
-b [bit count]       : Set bit count in generated image files
-a                   : Call ghostscript to convert postscript to image files
-e                   : Append suffix to single page image file, (eg. out0001.jpg)
-#                   : Set your License Key
-?                   : Help
-------------------------------------------------------
Example:
    ps2img -i C:\input.ps -o C:\output.tif
    ps2img -i C:\input.eps -o C:\output.tif
    ps2img -m -i C:\input.ps -o C:\output.tif
    ps2img -c lzw -i C:\input.ps -o C:\output.tif
    ps2img -q 80 -i C:\input.ps -o C:\output.jpg
    ps2img -b 4 -i C:\input.ps -o C:\output.tif
    ps2img -i C:\input.ps -o C:\output.tif -b 1 -c ClassF -r 204x98 -m
    ps2img -f 1 -l 9 C:\input.ps -o C:\output.jpg
    ps2img -i C:\*.ps -o C:\*.pcx
    ps2img "-#" "XXXXXXXXXXXXXXXX"
    ps2img "-#" "XXXXXXXXXXXXXXXX" -i C:\input.ps -o C:\output.tif
