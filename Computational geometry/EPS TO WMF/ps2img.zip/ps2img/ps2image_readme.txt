VeryDOC Postscript to Image Converter Command Line v2.0
Web: http://www.verypdf.com
Web: http://www.verydoc.com
Email: support@verypdf.com
Build: May 27 2014
-------------------------------------------------------
Key features in PS to Image Converter:
   Convert postscript files to various image formats.
   Use disk cache to render postscript to image files at any resolution.
   Various compression arithmetic for output TIFF files.
-------------------------------------------------------
Usage: ps2image.exe [options] [Options] <PS Files>
  -f <int>         : first page to print, from 1 to max page
  -l <int>         : last page to print, from 1 to max page
  -r <int>         : set resolution when render ps to image files
  -c <string>      : set compression method to generated TIFF files
    -c lzw           : Compress TIFF using LZW arithmetic
    -c packbit       : Compress TIFF using packbits arithmetic
    -c g3            : Compress TIFF using CCITT G3 arithmetic
    -c g4            : Compress TIFF using CCITT G4 arithmetic
    -c rlebmp        : Compress BMP using RunLength arithmetic
  -b <int>         : set bitcount when render ps to image files
  -forcebw         : force to create Black and White image file
  -debug           : print debug message
  -silent          : suppress log message
  -$ <string>      : input registration key
Example:
   ps2image.exe C:\input.ps C:\output.tif
   ps2image.exe -c g3 C:\input.ps C:\output.tif
   ps2image.exe -c g4 C:\input.ps C:\output.tif
   ps2image.exe -c lzw C:\input.ps C:\output.tif
   ps2image.exe -c packbit C:\input.ps C:\output.tif
   ps2image.exe C:\input.ps C:\output.jpg
   ps2image.exe C:\input.ps C:\output.bmp
   ps2image.exe C:\input.ps C:\output.pcx
   ps2image.exe C:\input.ps C:\output.png
   ps2image.exe C:\test\*.ps C:\test\*.jpg
   ps2image.exe C:\filelist.txt
